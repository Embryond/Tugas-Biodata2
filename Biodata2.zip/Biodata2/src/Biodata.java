/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Biodata {
    public void namaLengkap(){
        System.out.println("Nama : Krisantus Preyanda Embryond");
    }
    public void jenisKelamin(){
        System.out.println("Jenis Kelamin : Laki-laki");
    }
    public void Ttl(){
        System.out.println("TTL : Sidoarjo, 25 Oktober 2003");
    }
    public void Umur(){
        System.out.println("Umur : 16 Thn");
    }
    public void Alamat(){
        System.out.println("Alamat : Suwayuwo Perum OIK Raflesia D6-6");
    }
    public void Hobi(){
        System.out.println("Hobi : Game dan Basket");
    }
    public void Kelas(){
        System.out.println("Kelas : XI RPL 1");
    }
    public void Sekolah(){
        System.out.println("Sekolah : SMKN 1 Purwosari");
    }
    
    
}
